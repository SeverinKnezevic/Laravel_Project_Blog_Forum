<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <!-- Izbornik -->
            <div class="col-md-3">
                <ul class="list-group">
                    <li class="list-group-item"><a href="<?php echo e(route('naslovnica')); ?>">Naslovnica</a></li>
                    <li class="list-group-item"><a href="<?php echo e(route('objava.prikaz')); ?>">Sve objave</a></li>
                    <li class="list-group-item"><a href="<?php echo e(route('komentar.prikaz')); ?>">Svi komentari</a></li>
                    <li class="list-group-item"><a href="#">Svi korisnici</a></li>
                </ul>
            </div>

            <!-- Sadržaj -->
            <div class="col-md-9">
                <?php echo $__env->yieldContent('sadrzaj'); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/projekt_/resources/views/layouts/admin.blade.php ENDPATH**/ ?>