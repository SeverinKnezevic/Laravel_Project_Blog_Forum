<?php $__env->startSection('sadrzaj'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-9">
                                <h3 style="margin-top: 5px;">Novi komentar</h3>
                            </div>
                            <div class="col-md-3"  style="text-align: right;">
                                <a href="<?php echo e(route('komentar.prikaz')); ?>" class="btn btn-danger">Vrati se</a>
                            </div>
                        </div>
                    </div>
                </div>
                <br/>
            </div>

            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="col-md-12">

                            <form action="<?php echo e(route('komentar.dodaj')); ?>" method="POST">
                                <!-- Svaka forma mora imati CSRF token! -->

                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label for="sadrzaj">Sadržaj *</label>
                                    <textarea name="sadrzaj" rows="5" class="form-control"
                                              placeholder="Unesi sadržaj"></textarea>
                                </div>

                                <div class="form-group">
                                    <label for="objava_id">Objava *</label>
                                    <select class="form-control" name="objava_id">
                                        <?php $__currentLoopData = $sve_objave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objava): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($objava->id); ?>"><?php echo e($objava->naslov); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <button type="submit" class="btn btn-primary">Spremi</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/projekt_/resources/views/komentar/dodaj.blade.php ENDPATH**/ ?>