<?php $__env->startSection('sadrzaj'); ?>
    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-9">
                                <h3 style="margin-top: 5px;">Sve objave</h3>
                            </div>
                            <div class="col-md-3"  style="text-align: right;">
                                <a href="<?php echo e(route('objava.dodaj')); ?>" class="btn btn-primary">Nova objava</a>
                            </div>
                        </div>
                    </div>
                </div>
                <br/>
            </div>

            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table class="table table-bordered">
                            <tr>
                                <th>Naslov</th>
                                <th>Sadržaj</th>
                                <th>Autor</th>
                                <th>Akcije</th>
                            </tr>

                            <?php $__currentLoopData = $objave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objava): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($objava->naslov); ?></td>
                                    <td><?php echo e($objava->sadrzaj); ?></td>
                                    <td><?php echo e($objava->autor->name); ?></td> <!-- Ovo je moguće jer smo definirali relaciju "autor" unutar datoteke Objava.class -->
                                    <td>
                                        <a href="<?php echo e(route('objava.uredi', $objava->id)); ?>">Uredi</a>
                                        |
                                        <a href="<?php echo e(route('objava.izbrisi', $objava->id)); ?>">Izbriši</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php if(sizeof($objave) == 0): ?>
                                <tr style="text-align: center;">
                                    <td colspan="4">Nažalost, ne postoji ni jedan zapis u bazi!</td>
                                </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/projekt_/resources/views/objava/pregled.blade.php ENDPATH**/ ?>