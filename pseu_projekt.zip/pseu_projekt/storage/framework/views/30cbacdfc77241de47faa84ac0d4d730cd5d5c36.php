<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <table class="table table-bordered">
                <tr>
                    <th>Naslov</th>
                    <th>Sadržaj</th>
                    <th>Autor</th>
                    <th>Akcije</th>
                </tr>

                <?php $__currentLoopData = $objave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objava): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($objava->naslov); ?></td>
                        <td><?php echo e($objava->sadrzaj); ?></td>
                        <td><?php echo e($objava->autor); ?></td>
                        <td>
                            <a href="<?php echo e(route('objave.forma_uredi', $objava->id)); ?>">Uredi</a>
                            |
                            <a href="<?php echo e(route('objave.izbrisi', $objava->id)); ?>">Izbriši</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/projekt_/resources/views/objave.blade.php ENDPATH**/ ?>