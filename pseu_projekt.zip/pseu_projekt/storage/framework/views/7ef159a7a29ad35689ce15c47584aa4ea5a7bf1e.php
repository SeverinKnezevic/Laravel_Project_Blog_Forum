<?php $__env->startSection('sadrzaj'); ?>
    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-9">
                                <h3 style="margin-top: 5px;">Svi komentari</h3>
                            </div>
                            <div class="col-md-3"  style="text-align: right;">
                                <a href="<?php echo e(route('komentar.dodaj')); ?>" class="btn btn-primary">Novi komentar</a>
                            </div>
                        </div>
                    </div>
                </div>
                <br/>
            </div>

            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <table class="table table-bordered">
                            <tr>
                                <th>Objava</th>
                                <th>Sadržaj</th>
                                <th>Autor</th>
                                <th>Akcije</th>
                            </tr>

                            <?php $__currentLoopData = $komentari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komentar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(route('objava.uredi', $komentar->objava_id)); ?>"><?php echo e($komentar->objava->naslov); ?></a></td>
                                    <td><?php echo e($komentar->sadrzaj); ?></td>
                                    <td><?php echo e($komentar->autor->name); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('komentar.uredi', $komentar->id)); ?>">Uredi</a>
                                        |
                                        <a href="<?php echo e(route('komentar.izbrisi', $komentar->id)); ?>">Izbriši</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php if(sizeof($komentari) == 0): ?>
                                <tr style="text-align: center;">
                                    <td colspan="4">Nažalost, ne postoji ni jedan zapis u bazi!</td>
                                </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/projekt_/resources/views/komentar/pregled.blade.php ENDPATH**/ ?>