<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">

                <form action="<?php echo e(route('objave.nova')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="naslov">Naslov *</label>
                        <input name="naslov" type="text" class="form-control" placeholder="Unesi naslov">
                    </div>

                    <div class="form-group">
                        <label for="sadrzaj">Sadržaj *</label>
                        <textarea name="sadrzaj" rows="5" class="form-control" placeholder="Unesi sadrzaj"></textarea>
                    </div>

                    <div class="form-group">
                        <label for="objava_id">Objava *</label>
                        <select class="form-control" name="objava_id">
                            <?php $__currentLoopData = $sve_objave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objava): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($objava->id); ?>"><?php echo e($objava->naslov); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">Spremi</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/projekt_/resources/views/komentar.blade.php ENDPATH**/ ?>