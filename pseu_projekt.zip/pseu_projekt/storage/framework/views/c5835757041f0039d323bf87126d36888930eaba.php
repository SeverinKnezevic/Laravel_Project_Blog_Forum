<?php $__env->startSection('sadrzaj'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-9">
                                <h3 style="margin-top: 5px;"><?php echo e($objava->naslov); ?></h3>
                            </div>
                            <div class="col-md-3"  style="text-align: right;">
                                <a href="<?php echo e(route('objava.prikaz')); ?>" class="btn btn-danger">Vrati se</a>
                            </div>
                        </div>
                    </div>
                </div>
                <br/>
            </div>

            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="col-md-12">

                            <form action="<?php echo e(route('objava.uredi', $objava->id)); ?>" method="POST">
                                <!-- Svaka forma mora imati CSRF token! -->

                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label for="naslov">Naslov *</label>
                                    <input name="naslov" type="text" class="form-control" placeholder="Unesi naslov"
                                           value="<?php echo e($objava->naslov); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="sadrzaj">Sadržaj *</label>
                                    <textarea name="sadrzaj" rows="5" class="form-control"
                                              placeholder="Unesi sadržaj"><?php echo e($objava->sadrzaj); ?></textarea>
                                </div>

                                <div class="form-group">
                                    <label for="istaknuta">Istaknuto *</label>
                                    <select class="form-control" name="istaknuta">
                                        <option value="0" <?php if($objava->istaknuta == 0): ?> selected <?php endif; ?>>Ne</option>
                                        <option value="1" <?php if($objava->istaknuta == 1): ?> selected <?php endif; ?>>Da</option>
                                    </select>
                                </div>

                                <button type="submit" class="btn btn-primary">Spremi</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/projekt_/resources/views/objava/uredi.blade.php ENDPATH**/ ?>